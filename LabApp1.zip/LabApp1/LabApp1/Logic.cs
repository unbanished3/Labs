﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabApp1
{
    internal class Logic
    {
        public MainRecord11 Add(MainRecord11 record, MemoryDataSource records)
        {
            foreach(string i in record.CategoriesList)
            {
                int counter = 0;
                foreach(char j in i)
                {
                    if(j == ' ') counter++;
                    if (counter == 2) return null;
                }
            }
            if (record.AverageCheck <= 0) return null;
            return records.Save(record);
        }

        public bool Remove(int id, MemoryDataSource records)
        {
            return records.Delete(id);
        }
        public List<MainRecord11> Drop(MemoryDataSource records)
        {
            return records.GetAll();
        }
        public MainRecord11 Take(int id, MemoryDataSource records)
        {
            return records.Get(id);
        }
    }
}
