﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabApp1
{
    internal class MemoryDataSource : IDataSource
    {
        private List<MainRecord11> records = new List<MainRecord11>();

        public MainRecord11 Save(MainRecord11 record)
        {
            if(record.id == 0)
            {
                if(records.Count() > 0)
                {
                    record.id = records.Last().id + 1;
                }
                else
                {
                    record.id = 1;
                }
                records.Add(record);
                return record;
            }
            int index = records.IndexOf(records.Single(x => x.id == record.id));
            records[index] = record;
            return records[index];
        }
        public MainRecord11 Get(int id)
        {
            if(id == 0) { return null; }
            return records.Single(x => x.id == id);
        }
        public bool Delete(int id)
        {
            MainRecord11 item = records.Single(x => x.id == id);
            return records.Remove(item);
        }
        public List<MainRecord11> GetAll()
        {
            var sortList = records.OrderBy(x => x.City).ThenBy(x => x.name);
            return sortList.ToList();
        }
    }
}
