﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabApp1
{
    internal class NetRecord : MainRecord11 ///Сеть ресторанов
    {
        public NetRecord(string col, string name, int AvCheck, List<string> CList, string City) :base(name, AvCheck, CList, City)
        {
            this.col = col;
        }
    }
}
