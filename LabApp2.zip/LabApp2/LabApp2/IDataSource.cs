﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabApp1
{
    public interface IDataSource
    {
        MainRecord11 Save(MainRecord11 record);
        MainRecord11 Get(int id);
        bool Delete(int id);
        List<MainRecord11> GetAll();
    }
}
