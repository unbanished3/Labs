﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace LabApp1
{
    internal class Logic
    {
        public MainRecord11 Add(MainRecord11 record, FileDataSource records)
        {
            int counter = 0;
            foreach(char j in record.CategoriesList)
            {
                if (j == ' ') counter++;
                if (j == ',') counter = 0;
                if (counter == 2) return null;
            }
            if (record.AverageCheck <= 0) return null;
            return records.Save(record);
        }

        public bool Remove(int id, FileDataSource records)
        {
            return records.Delete(id);
        }
        public List<MainRecord11> Drop(FileDataSource records)
        {
            return records.GetAll();
        }
        public MainRecord11 Take(int id, FileDataSource records)
        {
            return records.Get(id);
        }
        public void Generate(int minCheck, int maxCheck, string Path, FileDataSource records)
        {
            StreamWriter file = new StreamWriter(Path);
            List<MainRecord11> list = new List<MainRecord11>(records.GetAll());
            Dictionary<string, int> cities = new Dictionary<string, int>();
            foreach (MainRecord11 record in list)
            {
                if(record.AverageCheck < minCheck) continue;
                if(record.AverageCheck > maxCheck) continue;

                if (cities.ContainsKey(record.City)){
                    cities[record.City]++;
                }
                else
                {
                    cities.Add(record.City, 1);
                }
            }
            foreach(KeyValuePair<string, int> pair in cities)
            {
                file.WriteLine(pair.Key + " : " + pair.Value.ToString());
            }
            file.Close();
        }
        public void CreateClearBin(string path)
        {
            ///if (File.Exists(path)) { return; }
            using (BinaryWriter writer = new BinaryWriter(File.Open(path, FileMode.OpenOrCreate)))
            {
                writer.Write("DmitrySa");
            }
        }
        public static void WriteToBin(string path, MainRecord11 record)
        {
            using (BinaryWriter writer = new BinaryWriter(File.Open(path, FileMode.Append)))
            {
                writer.Write(new string(' ', 32 - record.name.Length) + record.name);
                writer.Write(new string(' ', 32 - record.CategoriesList.Length) + record.CategoriesList);
                writer.Write(new string(' ', 32 - record.City.Length) + record.City);
                writer.Write(new string(' ', 32 - record.type.Length) + record.type);
                if (record.type == "net")
                {
                    writer.Write(new string(' ', 32 - record.col.Length) + record.col);
                }
                else
                {
                    writer.Write(new string(' ', 32 - record.time.Length) + record.time);
                }
                writer.Write(new string(' ', 32 - record.id.ToString().Length) + record.id.ToString());
                writer.Write(new string(' ', 34 - record.id.ToString().Length) + record.AverageCheck);
            }
        }

        public static void RewriteBin(FileDataSource records)
        {
            File.WriteAllText(records.path, string.Empty);
            using (BinaryWriter writer = new BinaryWriter(File.Open(records.path, FileMode.OpenOrCreate)))
            {
                writer.Write("DmitrySa");
            }
            foreach (MainRecord11 record in records.GetAll())
            {
                Logic.WriteToBin(records.path, record);
            }
        }
    }
}
