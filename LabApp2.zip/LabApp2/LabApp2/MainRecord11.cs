﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabApp1
{
    abstract public class MainRecord11
    {
        public int id = 0;
        public string name;
        public int AverageCheck;
        public string CategoriesList;
        public string City;
        public string col;
        public string time;
        public string type;

        public MainRecord11(string name, int AvCheck, string CList, string City) ///конструктор основной записи, наследуемые классы добавят свои поля
        {
            this.name = name;
            this.AverageCheck = AvCheck;
            this.CategoriesList = CList;
            this.City = City;
        }
    }
}
