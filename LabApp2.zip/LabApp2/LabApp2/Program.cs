﻿using LabApp1;
Logic Handler = new Logic();
Handler.CreateClearBin("file.dat");
FileDataSource records = new FileDataSource("file.dat");
Console.WriteLine(sizeof(char));

int on = 1;
while (on == 1)
{
    Console.WriteLine("1. Добавить запись");
    Console.WriteLine("2. Посмотреть записи");
    Console.WriteLine("3. Изменить запись");
    Console.WriteLine("4. Удалить запись");
    Console.WriteLine("5. Создать отчёт");
    Console.WriteLine("6. Выйти");
    switch (Console.ReadLine())
    {
        case "1":
            Console.WriteLine("1. Ресторан быстрого питания");
            Console.WriteLine("2. Сеть ресторанов");
            string choice = Console.ReadLine();
            Console.WriteLine("Введите название ресторана");
            string name = Console.ReadLine();
            Console.WriteLine("Введите средний чек(только число)");
            int AvCheck = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите Город");
            string City = Console.ReadLine();
            Console.WriteLine("Введите категории");
            string CList = Console.ReadLine();
            switch (choice)
            {
                case "1":
                    Console.WriteLine("Введите время доставки");
                    string time = Console.ReadLine();
                    Handler.Add(new FastFoodRecord(time, name, AvCheck, CList, City), records);
                    break;
                case "2":
                    Console.WriteLine("Введите кол-во ресторанов");
                    string col = Console.ReadLine();
                    Handler.Add(new NetRecord(col, name, AvCheck, CList, City), records);
                    break;
            }

            break;
        case "2":
            foreach(var record in records.GetAll())
            {
                Console.Write(record.id.ToString() + " ");
                Console.Write(record.name + " ");
                Console.Write(record.AverageCheck.ToString() + " ");
                Console.Write(record.City + " ");
                if(record is NetRecord)
                {
                    Console.Write(record.col + " ");
                }
                else
                {
                    Console.Write(record.time + " ");
                }
                Console.Write(record.CategoriesList + "\n");
            }
            break;
        case "3":
            Console.WriteLine("Введите номер записи");
            int num = int.Parse(Console.ReadLine());
            var change = Handler.Take(num, records);
            num = change.id;
            if(change == null) { break; }
            Console.WriteLine("Введите название ресторана");
            change.name = Console.ReadLine();
            Console.WriteLine("Введите средний чек(только число)");
            change.AverageCheck = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите Город");
            change.City = Console.ReadLine();
            Console.WriteLine("Введите категории");
            change.CategoriesList = Console.ReadLine();
            if(change is NetRecord)
            {
                Console.WriteLine("Введите кол-во ресторанов");
                string col = Console.ReadLine();
                change.col = col;
            }
            else
            {
                Console.WriteLine("Введите время доставки");
                string time = Console.ReadLine();
                change.time = time;
            }
            Handler.Add(change, records);
            break;
        case "4":
            Console.WriteLine("Введите номер удаляемой записи");
            int del = int.Parse(Console.ReadLine());
            Handler.Remove(del, records);
            break;
        case "5":
            Console.WriteLine("Введите минимальное значение среднего чека");
            int min = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите максимальное значение среднего чека");
            int max = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите путь до файла");
            string path = Console.ReadLine();
            Handler.Generate(min, max, path, records);
            break;
        case "6":
            on = 0;
            break;
    }
}


