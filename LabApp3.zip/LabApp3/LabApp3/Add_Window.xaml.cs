﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LabApp3
{
    /// <summary>
    /// Логика взаимодействия для Add_Window.xaml
    /// </summary>
    public partial class Add_Window : Window
    {
        MainWindow Form = Application.Current.Windows[0] as MainWindow;
        FileDataSource records;
        Logic Handler;
        int index;
        public Add_Window(FileDataSource records, Logic Handler, int index)
        {
            this.records = records;
            this.Handler = Handler;
            this.index = index;
            InitializeComponent();
        }

        private void FastFood_Checked(object sender, RoutedEventArgs e)
        {
            FastFood_Field.IsEnabled = true;
            Net_Field.IsEnabled = false;
        }

        private void Net_Checked(object sender, RoutedEventArgs e)
        {
            FastFood_Field.IsEnabled = false;
            Net_Field.IsEnabled = true;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            //Проверяем все поля ввода
            if(name_Field.Text == null) { return; }
            string name = name_Field.Text;
            if(AverageCheck_Field.Text == null) { return; }
            if(City_Field.Text == null) { return; }
            string City = City_Field.Text;
            if(CategoriesList_Field.Text == null) { return; }
            string CList = CategoriesList_Field.Text;
            if(FastFood_Field.IsEnabled && FastFood_Field.Text == null) { return; }
            if(Net_Field.IsEnabled && Net_Field.Text == null) { return; }
            int AVCheck;
            try
            {
                AVCheck = int.Parse(AverageCheck_Field.Text);
            }
            catch (Exception)
            {
                AVCheck = 0;
                return;
            }
            if(FastFood_Field.IsEnabled)
            {
                string time = FastFood_Field.Text;
                FastFoodRecord NewRecord = new FastFoodRecord(time, name, AVCheck, CList, City);
                if(index >= 0)
                {
                    StringBuilder id = new StringBuilder();
                    foreach (char i in Form.Record_List.SelectedItem.ToString())
                    {
                        if (i == ' ') { break; }
                        id.Append(i);
                    }
                    NewRecord.id = int.Parse(id.ToString());
                    Handler.Add(NewRecord, records);
                    Form.Record_List.Items.RemoveAt(index);
                    Form.Record_List.Items.Insert(index, NewRecord.id + " " + name + " " + City + " " + AVCheck.ToString() + " " + time + " " + CList);
                    return;
                }
                Handler.Add(NewRecord, records);
                Form.Record_List.Items.Add(NewRecord.id + " " + name + " " + City + " " + AVCheck.ToString() + " " + time + " " + CList);
            }
            if (Net_Field.IsEnabled)
            {
                string col = Net_Field.Text;
                NetRecord NewRecord = new NetRecord(col, name, AVCheck, CList, City);
                if (index >= 0)
                {
                    StringBuilder id = new StringBuilder();
                    foreach (char i in Form.Record_List.SelectedItem.ToString())
                    {
                        if (i == ' ') { break; }
                        id.Append(i);
                    }
                    NewRecord.id = int.Parse(id.ToString());
                    Handler.Add(NewRecord, records);
                    Form.Record_List.Items.RemoveAt(index);
                    Form.Record_List.Items.Insert(index, NewRecord.id + " " + name + " " + City + " " + AVCheck.ToString() + " " + col + " " + CList);
                    return;
                }
                Handler.Add(NewRecord, records);
                Form.Record_List.Items.Add(NewRecord.id + " " + name + " " + City + " " + AVCheck.ToString() + " " + col + " " + CList);
            }
        }
    }
}
