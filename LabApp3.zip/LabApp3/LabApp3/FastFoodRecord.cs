﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabApp3
{
    public class FastFoodRecord : MainRecord11 /// Ресторан быстрого питания
    {
        public FastFoodRecord(string time, string name, int AvCheck, string CList, string City) : base(name, AvCheck, CList, City)/// Добавляет время доставки 
        {
            this.time = time;
            this.type = "fast";
        }
    }
}
