﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LabApp3
{
    public class FileDataSource : IDataSource
    {
        private List<MainRecord11> records = new List<MainRecord11>();
        public string path;

        public FileDataSource(string path) 
        {
            this.path = path;
            using (BinaryReader reader = new BinaryReader(File.Open(path, FileMode.Open)))
            {
                string signature = reader.ReadString();
                if(signature != "DmitrySa")
                {
                    throw (new Exception("Выбран неверный файл"));
                }
                if(reader.BaseStream.Position >= reader.BaseStream.Length)
                {
                    return;
                }
                while (reader.BaseStream.Position < reader.BaseStream.Length)
                {
                    try
                    {
                        string name = reader.ReadString().Trim();
                        string Categories = reader.ReadString().Trim();
                        string City = reader.ReadString().Trim();
                        string type = reader.ReadString().Trim();
                        string Addition = reader.ReadString().Trim();
                        int id = int.Parse(reader.ReadString().Trim());
                        int AverageCheck = int.Parse(reader.ReadString().Trim());
                        if (type == "net")
                        {
                            NetRecord obj = new NetRecord(Addition, name, AverageCheck,Categories, City);
                            obj.id = id;
                            records.Add(obj);
                        }
                        else
                        {
                            FastFoodRecord obj = new FastFoodRecord(Addition, name, AverageCheck, Categories, City);
                            obj.id = id;
                            records.Add(obj);
                        }
                    }
                    catch(Exception)
                    {
                        break;
                    }
                }
            }
        }
        public MainRecord11 Save(MainRecord11 record)
        {
            if(record.id == 0)
            {
                if(records.Count() > 0)
                {
                    record.id = records.Last().id + 1;
                }
                else
                {
                    record.id = 1;
                }
                records.Add(record);
                Logic.WriteToBin(path, record);
                return record;
            }
            int index = records.IndexOf(records.Single(x => x.id == record.id));
            records[index] = record;
            Logic.RewriteBin(this);
            return records[index];
        }

        public MainRecord11 Get(int id)
        {
            if(id == 0) { return null; }
            return records.Single(x => x.id == id);
        }
        public bool Delete(int id)
        {
            MainRecord11 item = records.Single(x => x.id == id);
            bool t = records.Remove(item);
            Logic.RewriteBin(this);
            return t;
        }
        public List<MainRecord11> GetAll()
        {
            var sortList = records.OrderBy(x => x.City).ThenBy(x => x.name);
            return sortList.ToList();
        }
    }
}
