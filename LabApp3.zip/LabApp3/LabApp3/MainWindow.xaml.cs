﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace LabApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Logic Handler = new Logic();
        FileDataSource records = new FileDataSource("text.dat");
        ListBoxItem item;
        List<MainRecord11> list;
        public MainWindow()
        {
            InitializeComponent();
            list = records.GetAll();
            ///Handler.CreateClearBin("text.dat");
            foreach (MainRecord11 record in list)
            {
                if (record is FastFoodRecord)
                {
                    Record_List.Items.Add(record.id + " " + record.name + " " + record.City + " " + record.AverageCheck.ToString() + " " + record.time + " " + record.CategoriesList);
                }
                if (record is NetRecord)
                {
                    Record_List.Items.Add(record.id + " " + record.name + " " + record.City + " " + record.AverageCheck.ToString() + " " + record.col + " " + record.CategoriesList);
                }
            }
        }
        private void Delete_Button_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder id = new StringBuilder();
            foreach(char i in Record_List.SelectedItem.ToString())
            {
                if(i == ' ') { break; }
                id.Append(i);
            }
            Handler.Remove(int.Parse(id.ToString()), records);
            Record_List.Items.Remove(Record_List.SelectedItem);
        }

        private void Change_Button_Click(object sender, RoutedEventArgs e)
        {
            Add_Window window = new Add_Window(records, Handler, Record_List.SelectedIndex);
            window.Show();
        }

        private void Add_Button_Click(object sender, RoutedEventArgs e)
        {
            Add_Window window = new Add_Window(records, Handler, -1);
            window.Show();
        }

        private void Record_List_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            item = ItemsControl.ContainerFromElement(Record_List, e.OriginalSource as DependencyObject) as ListBoxItem;
            if (item != null)
            {
                Delete_Button.IsEnabled = true;
                Change_Button.IsEnabled = true;
            }
        }

        private void Generate_Button_Click(object sender, RoutedEventArgs e)
        {
            int from;
            int to;
            try
            {
                from = int.Parse(From.Text);
                to = int.Parse(To.Text);
            }
            catch (Exception)
            {
                return;
            }
            Handler.Generate(from, to, "file.txt", records);
        }
    }
}
