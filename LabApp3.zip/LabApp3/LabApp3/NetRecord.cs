﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabApp3
{
    public class NetRecord : MainRecord11 ///Сеть ресторанов
    {
        public NetRecord(string col, string name, int AvCheck, string CList, string City) :base(name, AvCheck, CList, City)
        {
            this.col = col;
            this.type = "net";
        }
    }
}
